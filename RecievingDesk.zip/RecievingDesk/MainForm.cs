﻿using CSCI467Library;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoPartsSystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        bool admin = false;

        // UI Code

        private void UIpanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void UIpanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void UIbutton7_Click(object sender, EventArgs e)
        {
            Invalid_IDPW.Visible = false;
            MainPanel.Visible = false;
            Login.Visible = true;
            AIAW_UIbutton.Visible = false;
            AI_UIbutton.Visible = false;
            RIFW_UIbutton.Visible = false;
            PPL_UIbutton.Visible = false;
            CancelPrompt.Visible = false;
        }

        private void UIbutton1_Click(object sender, EventArgs e)
        {
            //Query database of ID and PW, check if ID is present
            // if not, : Invalid_IDPW.Visible = true;
            // if yes, check if PW matches corresponding PW in table for ID
            //    if not, " Invalid_IDPW.Visible = true;
            //    if yes, check if ID is Admin or Employee
            //       if Employee, EmployeeP.Visible = true;
            //       if Admin, MainPanel.Visible = true;

            // Testing the two panels for admin and employees
            if (ID_entry.Text.Contains("K") == true)
            {
                Login.Visible = false;
                MainPanel.Visible = true;
                admin = false;
                CSTP_UIbutton.Visible = false;
                AIAW_UIbutton.Visible = true;
                AI_UIbutton.Visible = true;
                RIFW_UIbutton.Visible = true;
                PPL_UIbutton.Visible = true;
                UIlabel4.Text = "   Employee Tools  ";
                AIAW_UIbutton.Location = new Point(439, 161);
                AI_UIbutton.Location = new Point(250, 161);
                RIFW_UIbutton.Location = new Point(439, 260);
                PPL_UIbutton.Location = new Point(250, 260);
            }
            if (ID_entry.Text.Contains("A") == true)
            {
                Login.Visible = false;
                MainPanel.Visible = true;
                admin = true;
                CSTP_UIbutton.Visible = true;
                AIAW_UIbutton.Visible = true;
                AI_UIbutton.Visible = true;
                RIFW_UIbutton.Visible = true;
                PPL_UIbutton.Visible = true;
                UIlabel4.Text = "Administrator Tools";
                AIAW_UIbutton.Location = new Point(494, 172);
                AI_UIbutton.Location = new Point(258, 232);
                RIFW_UIbutton.Location = new Point(343, 172);
                PPL_UIbutton.Location = new Point(192, 172);
                CSTP_UIbutton.Location = new Point(414, 232);
            }
            else Invalid_IDPW.Visible = true;
        }

        private void UIbutton14_Click(object sender, EventArgs e)
        {
            PrintPackingList.Visible = false;
            AddInvoice.Visible = false;
            AIAW.Visible = false;
            RIFW.Visible = false;
            Invalid_IDPW.Visible = false;
            MainPanel.Visible = false;
            CSTP_UIbutton.Visible = false;
            AIAW_UIbutton.Visible = false;
            AI_UIbutton.Visible = false;
            RIFW_UIbutton.Visible = false;
            PPL_UIbutton.Visible = false;
            LOGOFF.Visible = false;
            Login.Visible = true;
        }

        private void UIbutton2_Click(object sender, EventArgs e)
        {
            PrintPackingList.Visible = false;
            AddInvoice.Visible = false;
            AIAW.Visible = false;
            RIFW.Visible = false;
            CSTP.Visible = false;
            AIAW.Visible = false;
            AddInvoice.Visible = false;
            PrintPackingList.Visible = true;
            if (admin)
            {
                CSTP_UIbutton.Visible = true;

            }
            else
            {
                CSTP_UIbutton.Visible = false;

            }
            LOGOFF.Visible = false;
            AIAW_UIbutton.Visible = false;
            AI_UIbutton.Visible = false;
            RIFW_UIbutton.Visible = false;
            PPL_UIbutton.Visible = false;
            CancelPrompt.Visible = false;
        }

        private void UIbutton3_Click(object sender, EventArgs e)
        {
            PrintPackingList.Visible = false;
            RIFW.Visible = true;
            CSTP.Visible = false;
            AIAW.Visible = false;
            CSTP_UIbutton.Visible = false;
            AIAW_UIbutton.Visible = false;
            AI_UIbutton.Visible = false;
            RIFW_UIbutton.Visible = false;
            PPL_UIbutton.Visible = false;
            LOGOFF.Visible = false;
            AddInvoice.Visible = false;
        }

        private void UIbutton4_Click(object sender, EventArgs e)
        {
            PrintPackingList.Visible = false;
            RIFW.Visible = false;
            CSTP.Visible = false;
            AIAW.Visible = false;
            CSTP_UIbutton.Visible = false;
            AIAW_UIbutton.Visible = false;
            AI_UIbutton.Visible = false;
            RIFW_UIbutton.Visible = false;
            PPL_UIbutton.Visible = false;
            LOGOFF.Visible = false;
            AddInvoice.Visible = true;
        }

        private void UIbutton5_Click(object sender, EventArgs e)
        {
            CSTP.Visible = false;
            AddInvoice.Visible = false;
            PrintPackingList.Visible = false;
            RIFW.Visible = false;
            CSTP_UIbutton.Visible = false;
            AIAW_UIbutton.Visible = false;
            AI_UIbutton.Visible = false;
            RIFW_UIbutton.Visible = false;
            PPL_UIbutton.Visible = false;
            LOGOFF.Visible = false;
            AIAW.Visible = true;
        }

        private void UIbutton6_Click(object sender, EventArgs e)
        {
            AddInvoice.Visible = false;
            PrintPackingList.Visible = false;
            RIFW.Visible = false;
            AIAW.Visible = false;
            CSTP.Visible = true;
            CSTP_UIbutton.Visible = false;
            AIAW_UIbutton.Visible = false;
            AI_UIbutton.Visible = false;
            RIFW_UIbutton.Visible = false;
            PPL_UIbutton.Visible = false;
            LOGOFF.Visible = false;
  
        }

        private void UIbutton2_Click_1(object sender, EventArgs e)
        {
            if (admin)
            {
                CSTP_UIbutton.Visible = true;

            }
            else
            {
                CSTP_UIbutton.Visible = false;

            }
            LOGOFF.Visible = true;
            AIAW_UIbutton.Visible = true;
            AI_UIbutton.Visible = true;
            RIFW_UIbutton.Visible = true;
            PPL_UIbutton.Visible = true;
            AddInvoice.Visible = false;
            PrintPackingList.Visible = false;
            //Code for method implementation for Print Packing List goes here.
        }

        private void UIbutton1_Click_1(object sender, EventArgs e)
        {
            if (admin)
            {
                CSTP_UIbutton.Visible = true;

            }
            else
            {
                CSTP_UIbutton.Visible = false;

            }
            LOGOFF.Visible = true;
            AIAW_UIbutton.Visible = true;
            AI_UIbutton.Visible = true;
            RIFW_UIbutton.Visible = true;
            PPL_UIbutton.Visible = true;
            CancelPrompt.Visible = true;
        }

        private void UIbutton3_Click_1(object sender, EventArgs e)
        {
            //Cancel Prompt Confirm
            if (admin)
            {
                CSTP_UIbutton.Visible = true;

            }
            else
            {
                CSTP_UIbutton.Visible = false;

            }
            LOGOFF.Visible = true;
            AIAW_UIbutton.Visible = true;
            AI_UIbutton.Visible = true;
            RIFW_UIbutton.Visible = true;
            PPL_UIbutton.Visible = true;
            AIAW.Visible = false;
            RIFW.Visible = false;
            CSTP.Visible = false;
            AddInvoice.Visible = false;
            PrintPackingList.Visible = false;
            CancelPrompt.Visible = false;
        }

        private void UIbutton4_Click_1(object sender, EventArgs e)
        {
            //Cancel Prompt Back
            CSTP_UIbutton.Visible = false;
            AIAW_UIbutton.Visible = false;
            AI_UIbutton.Visible = false;
            RIFW_UIbutton.Visible = false;
            PPL_UIbutton.Visible = false;
            LOGOFF.Visible = false;
            CancelPrompt.Visible = false;
        }

        private void UIbutton5_Click_1(object sender, EventArgs e)
        {
            if (admin)
            {
                CSTP_UIbutton.Visible = true;

            }
            else
            {
                CSTP_UIbutton.Visible = false;

            }
            LOGOFF.Visible = true;
            AIAW_UIbutton.Visible = true;
            AI_UIbutton.Visible = true;
            RIFW_UIbutton.Visible = true;
            PPL_UIbutton.Visible = true;
            AddInvoice.Visible = false;
            RIFW.Visible = false;
            CancelPrompt.Visible = false;
            //Code for method implementation for Ret. Item from Warehouse goes here.
        }

        private void UIbutton6_Click_1(object sender, EventArgs e)
        {
            if (admin)
            {
                CSTP_UIbutton.Visible = true;

            }
            else
            {
                CSTP_UIbutton.Visible = false;

            }
            LOGOFF.Visible = true;
            AIAW_UIbutton.Visible = true;
            AI_UIbutton.Visible = true;
            RIFW_UIbutton.Visible = true;
            PPL_UIbutton.Visible = true;
            CancelPrompt.Visible = true;
        }

        private void UIbutton7_Click_1(object sender, EventArgs e)
        {
            if (admin)
            {
                CSTP_UIbutton.Visible = true;

            }
            else
            {
                CSTP_UIbutton.Visible = false;

            }
            LOGOFF.Visible = true;
            AIAW_UIbutton.Visible = true;
            AI_UIbutton.Visible = true;
            RIFW_UIbutton.Visible = true;
            PPL_UIbutton.Visible = true;
            CSTP.Visible = false;
            CancelPrompt.Visible = false;
            //Code for method implementation for Change Shipping Tax Parameters goes here.
        }

        private void UIbutton15_Click(object sender, EventArgs e)
        {
            if (admin)
            {
                CSTP_UIbutton.Visible = true;

            }
            else
            {
                CSTP_UIbutton.Visible = false;

            }
            LOGOFF.Visible = true;
            AIAW_UIbutton.Visible = true;
            AI_UIbutton.Visible = true;
            RIFW_UIbutton.Visible = true;
            PPL_UIbutton.Visible = true;
            CancelPrompt.Visible = true;
        }

        private void UIbutton16_Click(object sender, EventArgs e)
        {
            if (admin)
            {
                CSTP_UIbutton.Visible = true;

            }
            else
            {
                CSTP_UIbutton.Visible = false;

            }
            LOGOFF.Visible = true;
            AIAW_UIbutton.Visible = true;
            AI_UIbutton.Visible = true;
            RIFW_UIbutton.Visible = true;
            PPL_UIbutton.Visible = true;
            AddInvoice.Visible = false;
            AIAW.Visible = false;
            CancelPrompt.Visible = false;
            //Code for method implementation for Add Item at Warehouse goes here.
        }

        private void UIbutton17_Click(object sender, EventArgs e)
        {
            if (admin)
            {
                CSTP_UIbutton.Visible = true;

            }
            else
            {
                CSTP_UIbutton.Visible = false;

            }
            LOGOFF.Visible = true;
            AIAW_UIbutton.Visible = true;
            AI_UIbutton.Visible = true;
            RIFW_UIbutton.Visible = true;
            PPL_UIbutton.Visible = true;
            AddInvoice.Visible = false;
            CancelPrompt.Visible = true;
        }

        private void UIbutton18_Click(object sender, EventArgs e)
        {
            if (admin)
            {
                CSTP_UIbutton.Visible = true;

            }
            else
            {
                CSTP_UIbutton.Visible = false;

            }
            LOGOFF.Visible = true;
            AIAW_UIbutton.Visible = true;
            AI_UIbutton.Visible = true;
            RIFW_UIbutton.Visible = true;
            PPL_UIbutton.Visible = true;
            AddInvoice.Visible = false;
            CancelPrompt.Visible = false;
            //Code for method implementation for Add Invoice goes here.
        }

        private void UIbutton19_Click(object sender, EventArgs e)
        {
            if (admin)
            {
                CSTP_UIbutton.Visible = true;

            }
            else
            {
                CSTP_UIbutton.Visible = false;

            }
            LOGOFF.Visible = true;
            AIAW_UIbutton.Visible = true;
            AI_UIbutton.Visible = true;
            RIFW_UIbutton.Visible = true;
            PPL_UIbutton.Visible = true;
            // Recieve Item click
            CancelPrompt.Visible = true;
        }

        private void UIbutton20_Click(object sender, EventArgs e)
        {
            CSTP_UIbutton.Visible = false;
            LOGOFF.Visible = false;
            AIAW_UIbutton.Visible = false;
            AI_UIbutton.Visible = false;
            AddInvoice.Visible = true;
            RIFW_UIbutton.Visible = false;
            PPL_UIbutton.Visible = false;
            AIAW.Visible = false;
            RIFW.Visible = false;
            CSTP.Visible = false;
            PrintPackingList.Visible = false;
            // Recieve Item click
            CancelPrompt.Visible = false;
        }

        // Recieving Desk Code
        private void RecievingDesklabel1_Click(object sender, EventArgs e)
        {

        }

        private void RecievingDesklabel3_Click(object sender, EventArgs e)
        {

        }

        private void CheckAccept_Click(object sender, EventArgs e)
        {
            int err = 0;
            if (Int32.TryParse(ItemRecievedCode.Text, out err))
            {
                PartsDBConnector connection = new PartsDBConnector("blitz.cs.niu.edu", 3306, "student", "student");
                Part singlePart = connection.GetPartByID(Int32.Parse(ItemRecievedCode.Text));
                PartName.Text = singlePart.Name;
                PartName.Visible = true;
            }
            else { PartName.Text = "Error, not valid part"; }
        }

        private void RecievingDeskClear_Click(object sender, EventArgs e)
        {
            ItemRecievedCode.Text = "";
            Quantity.Text = "";
            PartName.Text = "";
            NumRecieved.Text = "";
            PartName.Visible = false;
        }


        // Add Item Code
        private void AddItemButton_Click(object sender, EventArgs e)
        {

        }
    }
}
