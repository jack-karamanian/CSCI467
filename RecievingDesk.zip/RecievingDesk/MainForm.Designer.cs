﻿namespace AutoPartsSystem
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Login = new System.Windows.Forms.Panel();
            this.Invalid_IDPW = new System.Windows.Forms.Panel();
            this.Invalid_flag = new System.Windows.Forms.Label();
            this.UIlabel3 = new System.Windows.Forms.Label();
            this.UIlabel2 = new System.Windows.Forms.Label();
            this.LOGIN_UIbutton = new System.Windows.Forms.Button();
            this.PW_entry = new System.Windows.Forms.TextBox();
            this.ID_entry = new System.Windows.Forms.TextBox();
            this.UIlabel1 = new System.Windows.Forms.Label();
            this.MainPanel = new System.Windows.Forms.Panel();
            this.CSTP = new System.Windows.Forms.Panel();
            this.UIlabel12 = new System.Windows.Forms.Label();
            this.AIAW = new System.Windows.Forms.Panel();
            this.UIlabel11 = new System.Windows.Forms.Label();
            this.AddInvoice = new System.Windows.Forms.Panel();
            this.UIlabel10 = new System.Windows.Forms.Label();
            this.RIFW = new System.Windows.Forms.Panel();
            this.RecieveItem_Title = new System.Windows.Forms.Label();
            this.PrintPackingList = new System.Windows.Forms.Panel();
            this.UIlabel8 = new System.Windows.Forms.Label();
            this.LOGOFF = new System.Windows.Forms.Button();
            this.CSTP_UIbutton = new System.Windows.Forms.Button();
            this.AIAW_UIbutton = new System.Windows.Forms.Button();
            this.AI_UIbutton = new System.Windows.Forms.Button();
            this.RIFW_UIbutton = new System.Windows.Forms.Button();
            this.PPL_UIbutton = new System.Windows.Forms.Button();
            this.UIlabel4 = new System.Windows.Forms.Label();
            this.UIbutton9 = new System.Windows.Forms.Button();
            this.UIlabel5 = new System.Windows.Forms.Label();
            this.UIbutton8 = new System.Windows.Forms.Button();
            this.UIbutton1 = new System.Windows.Forms.Button();
            this.UIbutton2 = new System.Windows.Forms.Button();
            this.CancelPrompt = new System.Windows.Forms.Panel();
            this.UIlabel7 = new System.Windows.Forms.Label();
            this.UIbutton3 = new System.Windows.Forms.Button();
            this.UIbutton4 = new System.Windows.Forms.Button();
            this.UIbutton5 = new System.Windows.Forms.Button();
            this.UIbutton6 = new System.Windows.Forms.Button();
            this.UIbutton7 = new System.Windows.Forms.Button();
            this.UIbutton15 = new System.Windows.Forms.Button();
            this.UIbutton16 = new System.Windows.Forms.Button();
            this.UIbutton17 = new System.Windows.Forms.Button();
            this.UIbutton18 = new System.Windows.Forms.Button();
            this.UIbutton19 = new System.Windows.Forms.Button();
            this.ItemRecievedCode = new System.Windows.Forms.TextBox();
            this.RecievingDesklabel1 = new System.Windows.Forms.Label();
            this.CheckAccept = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.NumRecieved = new System.Windows.Forms.TextBox();
            this.RecievingDesklabel2 = new System.Windows.Forms.Label();
            this.RecievingDesklabel3 = new System.Windows.Forms.Label();
            this.RecievingDesklabel4 = new System.Windows.Forms.Label();
            this.PartName = new System.Windows.Forms.Label();
            this.PartNameText = new System.Windows.Forms.TextBox();
            this.QuantityText = new System.Windows.Forms.TextBox();
            this.Quantity = new System.Windows.Forms.Label();
            this.Login.SuspendLayout();
            this.Invalid_IDPW.SuspendLayout();
            this.MainPanel.SuspendLayout();
            this.CSTP.SuspendLayout();
            this.AIAW.SuspendLayout();
            this.AddInvoice.SuspendLayout();
            this.RIFW.SuspendLayout();
            this.PrintPackingList.SuspendLayout();
            this.CancelPrompt.SuspendLayout();
            this.SuspendLayout();
            //
            // Add Item
            //
            this.AddItemPartID = new System.Windows.Forms.TextBox();
            this.AddItemPartIDLabel = new System.Windows.Forms.Label();
            this.AddItemQuantity = new System.Windows.Forms.TextBox();
            this.AddItemQuantityLabel = new System.Windows.Forms.Label();
            this.AddItemReason = new System.Windows.Forms.TextBox();
            this.AddItemReasonLabel = new System.Windows.Forms.Label();
            this.AddItem = new System.Windows.Forms.Button();
            //
            // Add Item Part ID
            //
            this.AIAW.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.AIAW.Controls.Add(this.AddItemPartID);
            this.AIAW.Controls.Add(this.AddItemReason);
            this.AIAW.Controls.Add(this.AddItemQuantity);
            this.AIAW.Controls.Add(this.AddItem);
            this.AIAW.Controls.Add(this.AddItemPartIDLabel);
            this.AIAW.Controls.Add(this.AddItemReasonLabel);
            this.AIAW.Controls.Add(this.AddItemQuantityLabel);
            //
            // Add Item Part ID
            //
            this.AddItemPartID.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.AddItemPartID.Location = new System.Drawing.Point(200, 150);
            this.AddItemPartID.Name = "AddItemPartID";
            this.AddItemPartID.Size = new System.Drawing.Size(193, 20);
            this.AddItemPartID.TabIndex = 2;
            //
            // Add Item Quantity
            //
            this.AddItemQuantity.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.AddItemQuantity.Location = new System.Drawing.Point(400, 150);
            this.AddItemQuantity.Name = "AddItemQuantity";
            this.AddItemQuantity.Size = new System.Drawing.Size(193, 20);
            this.AddItemQuantity.TabIndex = 2;
            //
            // Add Item Reason
            //
            this.AddItemReason.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.AddItemReason.Location = new System.Drawing.Point(200, 200);
            this.AddItemReason.Name = "AddItemReason";
            this.AddItemReason.Size = new System.Drawing.Size(193, 20);
            this.AddItemReason.TabIndex = 2;
            //
            // Add Item Part ID Label
            //
            this.AddItemPartIDLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.AddItemPartIDLabel.AutoSize = true;
            this.AddItemPartIDLabel.Location = new System.Drawing.Point(200, 135);
            this.AddItemPartIDLabel.Name = "AddItemPartIDLabel";
            this.AddItemPartIDLabel.Size = new System.Drawing.Size(143, 20);
            this.AddItemPartIDLabel.TabIndex = 1;
            this.AddItemPartIDLabel.Text = "Part ID";
            //
            // Add Item Quantity Label
            //
            this.AddItemQuantityLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.AddItemQuantityLabel.AutoSize = true;
            this.AddItemQuantityLabel.Location = new System.Drawing.Point(400, 135);
            this.AddItemQuantityLabel.Name = "AddItemQuantityLabel";
            this.AddItemQuantityLabel.Size = new System.Drawing.Size(143, 20);
            this.AddItemQuantityLabel.TabIndex = 1;
            this.AddItemQuantityLabel.Text = "Quantity";
            //
            // Add Item Reason Label
            //
            this.AddItemReasonLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.AddItemReasonLabel.AutoSize = true;
            this.AddItemReasonLabel.Location = new System.Drawing.Point(200, 185);
            this.AddItemReasonLabel.Name = "AddItemReasonLabel";
            this.AddItemReasonLabel.Size = new System.Drawing.Size(250, 20);
            this.AddItemReasonLabel.TabIndex = 1;
            this.AddItemReasonLabel.Text = "Reason for Change";
            //
            // Add Item Button
            //
            this.AddItem.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.AddItem.Location = new System.Drawing.Point(350, 250);
            this.AddItem.Name = "AddItem";
            this.AddItem.Size = new System.Drawing.Size(75, 23);
            this.AddItem.TabIndex = 3;
            this.AddItem.Text = "Add Item";
            this.AddItem.UseVisualStyleBackColor = true;
            this.AddItem.Click += new System.EventHandler(this.AddItemButton_Click);
            // 
            // Login
            // 
            this.Login.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Login.Controls.Add(this.Invalid_IDPW);
            this.Login.Controls.Add(this.UIlabel3);
            this.Login.Controls.Add(this.UIlabel2);
            this.Login.Controls.Add(this.LOGIN_UIbutton);
            this.Login.Controls.Add(this.PW_entry);
            this.Login.Controls.Add(this.ID_entry);
            this.Login.Controls.Add(this.UIlabel1);
            this.Login.Location = new System.Drawing.Point(0, 0);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(843, 584);
            this.Login.TabIndex = 0;
            this.Login.Paint += new System.Windows.Forms.PaintEventHandler(this.UIpanel1_Paint);
            // 
            // Invalid_IDPW
            // 
            this.Invalid_IDPW.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Invalid_IDPW.Controls.Add(this.Invalid_flag);
            this.Invalid_IDPW.Location = new System.Drawing.Point(318, 257);
            this.Invalid_IDPW.Name = "Invalid_IDPW";
            this.Invalid_IDPW.Size = new System.Drawing.Size(193, 29);
            this.Invalid_IDPW.TabIndex = 6;
            this.Invalid_IDPW.Visible = false;
            // 
            // Invalid_flag
            // 
            this.Invalid_flag.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Invalid_flag.AutoSize = true;
            this.Invalid_flag.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Invalid_flag.ForeColor = System.Drawing.Color.Red;
            this.Invalid_flag.Location = new System.Drawing.Point(31, 6);
            this.Invalid_flag.Name = "Invalid_flag";
            this.Invalid_flag.Size = new System.Drawing.Size(141, 16);
            this.Invalid_flag.TabIndex = 0;
            this.Invalid_flag.Text = "Invalid ID or Password";
            // 
            // UIlabel3
            // 
            this.UIlabel3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIlabel3.AutoSize = true;
            this.UIlabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UIlabel3.Location = new System.Drawing.Point(377, 205);
            this.UIlabel3.Name = "UIlabel3";
            this.UIlabel3.Size = new System.Drawing.Size(78, 20);
            this.UIlabel3.TabIndex = 5;
            this.UIlabel3.Text = "Password";
            // 
            // UIlabel2
            // 
            this.UIlabel2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIlabel2.AutoSize = true;
            this.UIlabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UIlabel2.Location = new System.Drawing.Point(365, 138);
            this.UIlabel2.Name = "UIlabel2";
            this.UIlabel2.Size = new System.Drawing.Size(100, 20);
            this.UIlabel2.TabIndex = 4;
            this.UIlabel2.Text = "Employee ID";
            // 
            // LOGIN_UIbutton
            // 
            this.LOGIN_UIbutton.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LOGIN_UIbutton.Location = new System.Drawing.Point(380, 286);
            this.LOGIN_UIbutton.Name = "LOGIN_UIbutton";
            this.LOGIN_UIbutton.Size = new System.Drawing.Size(75, 23);
            this.LOGIN_UIbutton.TabIndex = 3;
            this.LOGIN_UIbutton.Text = "Log In";
            this.LOGIN_UIbutton.UseVisualStyleBackColor = true;
            this.LOGIN_UIbutton.Click += new System.EventHandler(this.UIbutton1_Click);
            // 
            // PW_entry
            // 
            this.PW_entry.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.PW_entry.Location = new System.Drawing.Point(318, 231);
            this.PW_entry.Name = "PW_entry";
            this.PW_entry.Size = new System.Drawing.Size(193, 20);
            this.PW_entry.TabIndex = 2;
            // 
            // ID_entry
            // 
            this.ID_entry.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ID_entry.Location = new System.Drawing.Point(318, 169);
            this.ID_entry.Name = "ID_entry";
            this.ID_entry.Size = new System.Drawing.Size(193, 20);
            this.ID_entry.TabIndex = 1;
            // 
            // UIlabel1
            // 
            this.UIlabel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIlabel1.AutoSize = true;
            this.UIlabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UIlabel1.Location = new System.Drawing.Point(240, 61);
            this.UIlabel1.Name = "UIlabel1";
            this.UIlabel1.Size = new System.Drawing.Size(352, 55);
            this.UIlabel1.TabIndex = 0;
            this.UIlabel1.Text = "    Zone Auto";
            // 
            // MainPanel
            // 
            this.MainPanel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.MainPanel.Controls.Add(this.CancelPrompt);
            this.MainPanel.Controls.Add(this.AddInvoice);
            this.MainPanel.Controls.Add(this.AIAW);
            this.MainPanel.Controls.Add(this.UIlabel4);
            this.MainPanel.Controls.Add(this.CSTP);
            this.MainPanel.Controls.Add(this.RIFW);
            this.MainPanel.Controls.Add(this.PrintPackingList);
            this.MainPanel.Controls.Add(this.LOGOFF);
            this.MainPanel.Controls.Add(this.CSTP_UIbutton);
            this.MainPanel.Controls.Add(this.AIAW_UIbutton);
            this.MainPanel.Controls.Add(this.AI_UIbutton);
            this.MainPanel.Controls.Add(this.RIFW_UIbutton);
            this.MainPanel.Controls.Add(this.PPL_UIbutton);
            this.MainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainPanel.Location = new System.Drawing.Point(0, 0);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(843, 584);
            this.MainPanel.TabIndex = 6;
            this.MainPanel.Visible = false;
            // 
            // CSTP
            // 
            this.CSTP.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.CSTP.Controls.Add(this.UIbutton15);
            this.CSTP.Controls.Add(this.UIbutton7);
            this.CSTP.Controls.Add(this.UIlabel12);
            this.CSTP.Location = new System.Drawing.Point(9, 64);
            this.CSTP.Name = "CSTP";
            this.CSTP.Size = new System.Drawing.Size(819, 508);
            this.CSTP.TabIndex = 1;
            this.CSTP.Visible = false;
            // 
            // UIlabel12
            // 
            this.UIlabel12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIlabel12.AutoSize = true;
            this.UIlabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UIlabel12.Location = new System.Drawing.Point(212, 15);
            this.UIlabel12.Name = "UIlabel12";
            this.UIlabel12.Size = new System.Drawing.Size(347, 25);
            this.UIlabel12.TabIndex = 0;
            this.UIlabel12.Text = "Change Shipping / Tax Parameters";
            // 
            // AIAW
            // 
            this.AIAW.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.AIAW.Controls.Add(this.UIbutton17);
            this.AIAW.Controls.Add(this.UIbutton16);
            this.AIAW.Controls.Add(this.UIlabel11);
            this.AIAW.Location = new System.Drawing.Point(11, 66);
            this.AIAW.Name = "AIAW";
            this.AIAW.Size = new System.Drawing.Size(819, 506);
            this.AIAW.TabIndex = 1;
            this.AIAW.Visible = false;
            // 
            // UIlabel11
            // 
            this.UIlabel11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIlabel11.AutoSize = true;
            this.UIlabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UIlabel11.Location = new System.Drawing.Point(274, 15);
            this.UIlabel11.Name = "UIlabel11";
            this.UIlabel11.Size = new System.Drawing.Size(236, 25);
            this.UIlabel11.TabIndex = 0;
            this.UIlabel11.Text = "Add Item at Warehouse";
            // 
            // AddInvoice
            // 
            this.AddInvoice.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.AddInvoice.Controls.Add(this.UIbutton19);
            this.AddInvoice.Controls.Add(this.UIbutton18);
            this.AddInvoice.Controls.Add(this.UIlabel10);
            this.AddInvoice.Location = new System.Drawing.Point(11, 66);
            this.AddInvoice.Name = "AddInvoice";
            this.AddInvoice.Size = new System.Drawing.Size(819, 506);
            this.AddInvoice.TabIndex = 2;
            this.AddInvoice.Visible = false;
            // 
            // UIlabel10
            // 
            this.UIlabel10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIlabel10.AutoSize = true;
            this.UIlabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UIlabel10.Location = new System.Drawing.Point(329, 15);
            this.UIlabel10.Name = "UIlabel10";
            this.UIlabel10.Size = new System.Drawing.Size(124, 25);
            this.UIlabel10.TabIndex = 0;
            this.UIlabel10.Text = "Add Invoice";
            // 
            // RecieveItem_Title
            // 
            this.RecieveItem_Title.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.RecieveItem_Title.AutoSize = true;
            this.RecieveItem_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RecieveItem_Title.Location = new System.Drawing.Point(325, 15);
            this.RecieveItem_Title.Name = "UIlabel12";
            this.RecieveItem_Title.Size = new System.Drawing.Size(347, 25);
            this.RecieveItem_Title.TabIndex = 0;
            this.RecieveItem_Title.Text = "Recieve Item";
            // 
            // RIFW
            // 
            this.RIFW.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.RIFW.Controls.Add(this.UIbutton6);
            this.RIFW.Controls.Add(this.UIbutton5);
            this.RIFW.Controls.Add(this.RecieveItem_Title);
            this.RIFW.Location = new System.Drawing.Point(11, 66);
            this.RIFW.Name = "RIFW";
            this.RIFW.Size = new System.Drawing.Size(819, 506);
            this.RIFW.TabIndex = 7;
            this.RIFW.Visible = false;
            // 
            // PrintPackingList
            // 
            this.PrintPackingList.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.PrintPackingList.Controls.Add(this.UIbutton2);
            this.PrintPackingList.Controls.Add(this.UIbutton1);
            this.PrintPackingList.Controls.Add(this.UIlabel8);
            this.PrintPackingList.Location = new System.Drawing.Point(11, 66);
            this.PrintPackingList.Name = "PrintPackingList";
            this.PrintPackingList.Size = new System.Drawing.Size(819, 506);
            this.PrintPackingList.TabIndex = 7;
            this.PrintPackingList.Visible = false;
            // 
            // UIlabel8
            // 
            this.UIlabel8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIlabel8.AutoSize = true;
            this.UIlabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UIlabel8.Location = new System.Drawing.Point(301, 15);
            this.UIlabel8.Name = "UIlabel8";
            this.UIlabel8.Size = new System.Drawing.Size(179, 25);
            this.UIlabel8.TabIndex = 0;
            this.UIlabel8.Text = "Print Packing List";
            // 
            // LOGOFF
            // 
            this.LOGOFF.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LOGOFF.Location = new System.Drawing.Point(369, 432);
            this.LOGOFF.Name = "LOGOFF";
            this.LOGOFF.Size = new System.Drawing.Size(75, 23);
            this.LOGOFF.TabIndex = 6;
            this.LOGOFF.Text = "LOGOFF";
            this.LOGOFF.UseVisualStyleBackColor = true;
            this.LOGOFF.Click += new System.EventHandler(this.UIbutton7_Click);
            // 
            // CSTP_UIbutton
            // 
            this.CSTP_UIbutton.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.CSTP_UIbutton.Location = new System.Drawing.Point(414, 232);
            this.CSTP_UIbutton.Name = "CSTP_UIbutton";
            this.CSTP_UIbutton.Size = new System.Drawing.Size(130, 44);
            this.CSTP_UIbutton.TabIndex = 5;
            this.CSTP_UIbutton.Text = "Change Shipping / Tax Parameters";
            this.CSTP_UIbutton.UseVisualStyleBackColor = true;
            this.CSTP_UIbutton.Click += new System.EventHandler(this.UIbutton6_Click);
            // 
            // AIAW_UIbutton
            // 
            this.AIAW_UIbutton.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.AIAW_UIbutton.Location = new System.Drawing.Point(494, 172);
            this.AIAW_UIbutton.Name = "AIAW_UIbutton";
            this.AIAW_UIbutton.Size = new System.Drawing.Size(122, 44);
            this.AIAW_UIbutton.TabIndex = 4;
            this.AIAW_UIbutton.Text = "Add Item at Warehouse";
            this.AIAW_UIbutton.UseVisualStyleBackColor = true;
            this.AIAW_UIbutton.Click += new System.EventHandler(this.UIbutton5_Click);
            // 
            // AI_UIbutton
            // 
            this.AI_UIbutton.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.AI_UIbutton.Location = new System.Drawing.Point(258, 232);
            this.AI_UIbutton.Name = "AI_UIbutton";
            this.AI_UIbutton.Size = new System.Drawing.Size(122, 44);
            this.AI_UIbutton.TabIndex = 3;
            this.AI_UIbutton.Text = "Add Invoice";
            this.AI_UIbutton.UseVisualStyleBackColor = true;
            this.AI_UIbutton.Click += new System.EventHandler(this.UIbutton4_Click);
            // 
            // RIFW_UIbutton
            // 
            this.RIFW_UIbutton.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.RIFW_UIbutton.Location = new System.Drawing.Point(343, 172);
            this.RIFW_UIbutton.Name = "RIFW_UIbutton";
            this.RIFW_UIbutton.Size = new System.Drawing.Size(122, 44);
            this.RIFW_UIbutton.TabIndex = 2;
            this.RIFW_UIbutton.Text = "Recieve Item";
            this.RIFW_UIbutton.UseVisualStyleBackColor = true;
            this.RIFW_UIbutton.Click += new System.EventHandler(this.UIbutton3_Click);
            // 
            // PPL_UIbutton
            // 
            this.PPL_UIbutton.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.PPL_UIbutton.Location = new System.Drawing.Point(192, 172);
            this.PPL_UIbutton.Name = "PPL_UIbutton";
            this.PPL_UIbutton.Size = new System.Drawing.Size(122, 44);
            this.PPL_UIbutton.TabIndex = 1;
            this.PPL_UIbutton.Text = "Print Packing List";
            this.PPL_UIbutton.UseVisualStyleBackColor = true;
            this.PPL_UIbutton.Click += new System.EventHandler(this.UIbutton2_Click);
            // 
            // UIlabel4
            // 
            this.UIlabel4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIlabel4.AutoSize = true;
            this.UIlabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UIlabel4.Location = new System.Drawing.Point(251, 9);
            this.UIlabel4.Name = "UIlabel4";
            this.UIlabel4.Size = new System.Drawing.Size(318, 39);
            this.UIlabel4.TabIndex = 0;
            this.UIlabel4.Text = "Administrator Tools";
            // 
            // UIbutton9
            // 
            this.UIbutton9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton9.Location = new System.Drawing.Point(414, 119);
            this.UIbutton9.Name = "UIbutton9";
            this.UIbutton9.Size = new System.Drawing.Size(122, 44);
            this.UIbutton9.TabIndex = 4;
            this.UIbutton9.Text = "Recieve Item";
            this.UIbutton9.UseVisualStyleBackColor = true;
            // 
            // UIbutton8
            // 
            this.UIbutton8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton8.Location = new System.Drawing.Point(250, 119);
            this.UIbutton8.Name = "UIbutton8";
            this.UIbutton8.Size = new System.Drawing.Size(122, 44);
            this.UIbutton8.TabIndex = 2;
            this.UIbutton8.Text = "Print Packing List";
            this.UIbutton8.UseVisualStyleBackColor = true;
            // 
            // UIbutton1
            // 
            this.UIbutton1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton1.Location = new System.Drawing.Point(24, 464);
            this.UIbutton1.Name = "UIbutton1";
            this.UIbutton1.Size = new System.Drawing.Size(75, 23);
            this.UIbutton1.TabIndex = 1;
            this.UIbutton1.Text = "&Cancel";
            this.UIbutton1.UseVisualStyleBackColor = true;
            this.UIbutton1.Click += new System.EventHandler(this.UIbutton1_Click_1);
            // 
            // UIbutton2
            // 
            this.UIbutton2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton2.Location = new System.Drawing.Point(724, 464);
            this.UIbutton2.Name = "UIbutton2";
            this.UIbutton2.Size = new System.Drawing.Size(75, 23);
            this.UIbutton2.TabIndex = 2;
            this.UIbutton2.Text = "Submit";
            this.UIbutton2.UseVisualStyleBackColor = true;
            this.UIbutton2.Click += new System.EventHandler(this.UIbutton2_Click_1);
            // 
            // CancelPrompt
            // 
            this.CancelPrompt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.CancelPrompt.Controls.Add(this.UIbutton4);
            this.CancelPrompt.Controls.Add(this.UIbutton3);
            this.CancelPrompt.Controls.Add(this.UIlabel7);
            this.CancelPrompt.Location = new System.Drawing.Point(0, 61);
            this.CancelPrompt.Name = "CancelPrompt";
            this.CancelPrompt.Size = new System.Drawing.Size(843, 523);
            this.CancelPrompt.TabIndex = 8;
            this.CancelPrompt.Visible = false;
            // 
            // UIlabel7
            // 
            this.UIlabel7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIlabel7.AutoSize = true;
            this.UIlabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UIlabel7.Location = new System.Drawing.Point(348, 169);
            this.UIlabel7.Name = "UIlabel7";
            this.UIlabel7.Size = new System.Drawing.Size(139, 24);
            this.UIlabel7.TabIndex = 0;
            this.UIlabel7.Text = "Confirm Cancel";
            // 
            // UIbutton3
            // 
            this.UIbutton3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton3.Location = new System.Drawing.Point(453, 287);
            this.UIbutton3.Name = "UIbutton3";
            this.UIbutton3.Size = new System.Drawing.Size(75, 23);
            this.UIbutton3.TabIndex = 1;
            this.UIbutton3.Text = "&Cancel";
            this.UIbutton3.UseVisualStyleBackColor = true;
            this.UIbutton3.Click += new System.EventHandler(this.UIbutton3_Click_1);
            // 
            // UIbutton4
            // 
            this.UIbutton4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton4.Location = new System.Drawing.Point(304, 287);
            this.UIbutton4.Name = "UIbutton4";
            this.UIbutton4.Size = new System.Drawing.Size(75, 23);
            this.UIbutton4.TabIndex = 2;
            this.UIbutton4.Text = "&Back";
            this.UIbutton4.UseVisualStyleBackColor = true;
            this.UIbutton4.Click += new System.EventHandler(this.UIbutton4_Click_1);
            // 
            // UIbutton5
            // 
            this.UIbutton5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton5.Location = new System.Drawing.Point(724, 464);
            this.UIbutton5.Name = "UIbutton5";
            this.UIbutton5.Size = new System.Drawing.Size(75, 23);
            this.UIbutton5.TabIndex = 3;
            this.UIbutton5.Text = "Submit";
            this.UIbutton5.UseVisualStyleBackColor = true;
            this.UIbutton5.Click += new System.EventHandler(this.UIbutton5_Click_1);
            // 
            // UIbutton6
            // 
            this.UIbutton6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton6.Location = new System.Drawing.Point(24, 464);
            this.UIbutton6.Name = "UIbutton6";
            this.UIbutton6.Size = new System.Drawing.Size(75, 23);
            this.UIbutton6.TabIndex = 4;
            this.UIbutton6.Text = "&Cancel";
            this.UIbutton6.UseVisualStyleBackColor = true;
            this.UIbutton6.Click += new System.EventHandler(this.UIbutton6_Click_1);
            // 
            // UIbutton7
            // 
            this.UIbutton7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton7.Location = new System.Drawing.Point(726, 466);
            this.UIbutton7.Name = "UIbutton7";
            this.UIbutton7.Size = new System.Drawing.Size(75, 23);
            this.UIbutton7.TabIndex = 4;
            this.UIbutton7.Text = "Submit";
            this.UIbutton7.UseVisualStyleBackColor = true;
            this.UIbutton7.Click += new System.EventHandler(this.UIbutton7_Click_1);
            // 
            // UIbutton15
            // 
            this.UIbutton15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton15.Location = new System.Drawing.Point(26, 466);
            this.UIbutton15.Name = "UIbutton15";
            this.UIbutton15.Size = new System.Drawing.Size(75, 23);
            this.UIbutton15.TabIndex = 5;
            this.UIbutton15.Text = "&Cancel";
            this.UIbutton15.UseVisualStyleBackColor = true;
            this.UIbutton15.Click += new System.EventHandler(this.UIbutton15_Click);
            // 
            // UIbutton16
            // 
            this.UIbutton16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton16.Location = new System.Drawing.Point(724, 464);
            this.UIbutton16.Name = "UIbutton16";
            this.UIbutton16.Size = new System.Drawing.Size(75, 23);
            this.UIbutton16.TabIndex = 5;
            this.UIbutton16.Text = "Submit";
            this.UIbutton16.UseVisualStyleBackColor = true;
            this.UIbutton16.Click += new System.EventHandler(this.UIbutton16_Click);
            // 
            // UIbutton17
            // 
            this.UIbutton17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton17.Location = new System.Drawing.Point(24, 464);
            this.UIbutton17.Name = "UIbutton17";
            this.UIbutton17.Size = new System.Drawing.Size(75, 23);
            this.UIbutton17.TabIndex = 6;
            this.UIbutton17.Text = "&Cancel";
            this.UIbutton17.UseVisualStyleBackColor = true;
            this.UIbutton17.Click += new System.EventHandler(this.UIbutton17_Click);
            // 
            // UIbutton18
            // 
            this.UIbutton18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton18.Location = new System.Drawing.Point(724, 464);
            this.UIbutton18.Name = "UIbutton18";
            this.UIbutton18.Size = new System.Drawing.Size(75, 23);
            this.UIbutton18.TabIndex = 6;
            this.UIbutton18.Text = "Submit";
            this.UIbutton18.UseVisualStyleBackColor = true;
            this.UIbutton18.Click += new System.EventHandler(this.UIbutton18_Click);
            // 
            // UIbutton19
            // 
            this.UIbutton19.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.UIbutton19.Location = new System.Drawing.Point(24, 464);
            this.UIbutton19.Name = "UIbutton19";
            this.UIbutton19.Size = new System.Drawing.Size(75, 23);
            this.UIbutton19.TabIndex = 7;
            this.UIbutton19.Text = "&Cancel";
            this.UIbutton19.UseVisualStyleBackColor = true;
            this.UIbutton19.Click += new System.EventHandler(this.UIbutton19_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(843, 584);
            this.Controls.Add(this.MainPanel);
            this.Controls.Add(this.Login);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Login.ResumeLayout(false);
            this.Login.PerformLayout();
            this.Invalid_IDPW.ResumeLayout(false);
            this.Invalid_IDPW.PerformLayout();
            this.MainPanel.ResumeLayout(false);
            this.MainPanel.PerformLayout();
            this.CSTP.ResumeLayout(false);
            this.CSTP.PerformLayout();
            this.AIAW.ResumeLayout(false);
            this.AIAW.PerformLayout();
            this.AddInvoice.ResumeLayout(false);
            this.AddInvoice.PerformLayout();
            this.RIFW.ResumeLayout(false);
            this.RIFW.PerformLayout();
            this.PrintPackingList.ResumeLayout(false);
            this.PrintPackingList.PerformLayout();
            this.CancelPrompt.ResumeLayout(false);
            this.CancelPrompt.PerformLayout();
            this.ResumeLayout(false);
            // 
            // RecievingDeskItemRecievedCode
            // 
            this.ItemRecievedCode.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ItemRecievedCode.Location = new System.Drawing.Point(200, 150);
            this.ItemRecievedCode.Name = "RecievingDeskItemRecievedCode";
            this.ItemRecievedCode.Size = new System.Drawing.Size(229, 26);
            this.ItemRecievedCode.TabIndex = 0;
            // 
            // RecievingDesklabel1
            // 
            this.RecievingDesklabel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.RecievingDesklabel1.AutoSize = true;
            this.RecievingDesklabel1.Location = new System.Drawing.Point(200, 135);
            this.RecievingDesklabel1.Name = "RecievingDesklabel1";
            this.RecievingDesklabel1.Size = new System.Drawing.Size(143, 20);
            this.RecievingDesklabel1.TabIndex = 1;
            this.RecievingDesklabel1.Text = "Item recieved code";
            this.RecievingDesklabel1.Click += new System.EventHandler(this.RecievingDesklabel1_Click);
            // 
            // CheckAccept
            // 
            this.CheckAccept.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.CheckAccept.Location = new System.Drawing.Point(400,350);
            this.CheckAccept.Name = "CheckAccept";
            this.CheckAccept.Size = new System.Drawing.Size(100, 34);
            this.CheckAccept.TabIndex = 2;
            this.CheckAccept.Text = "Check/Accept";
            this.CheckAccept.UseVisualStyleBackColor = true;
            this.CheckAccept.Click += new System.EventHandler(this.CheckAccept_Click);
            // 
            // Clear
            // 
            this.Clear.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Clear.Location = new System.Drawing.Point(300, 350);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(75, 32);
            this.Clear.TabIndex = 3;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.RecievingDeskClear_Click);
            // 
            // NumRecieved
            // 
            this.NumRecieved.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.NumRecieved.Location = new System.Drawing.Point(500, 150);
            this.NumRecieved.Name = "NumRecieved";
            this.NumRecieved.Size = new System.Drawing.Size(129, 26);
            this.NumRecieved.TabIndex = 4;
            // 
            // RecievingDesklabel2
            // 
            this.RecievingDesklabel2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.RecievingDesklabel2.AutoSize = true;
            this.RecievingDesklabel2.Location = new System.Drawing.Point(500, 135);
            this.RecievingDesklabel2.Name = "RecievingDesklabel2";
            this.RecievingDesklabel2.Size = new System.Drawing.Size(135, 20);
            this.RecievingDesklabel2.TabIndex = 5;
            this.RecievingDesklabel2.Text = "Number Recieved";
            // 
            // RecievingDesklabel3
            // 
            this.RecievingDesklabel3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.RecievingDesklabel3.AutoSize = true;
            this.RecievingDesklabel3.Location = new System.Drawing.Point(200, 250);
            this.RecievingDesklabel3.Name = "RecievingDesklabel3";
            this.RecievingDesklabel3.Size = new System.Drawing.Size(84, 20);
            this.RecievingDesklabel3.TabIndex = 6;
            this.RecievingDesklabel3.Text = "Part Name";
            this.RecievingDesklabel3.Click += new System.EventHandler(this.RecievingDesklabel3_Click);
            // 
            // RecievingDesklabel4
            // 
            this.RecievingDesklabel4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.RecievingDesklabel4.AutoSize = true;
            this.RecievingDesklabel4.Location = new System.Drawing.Point(500, 250);
            this.RecievingDesklabel4.Name = "RecievingDesklabel4";
            this.RecievingDesklabel4.Size = new System.Drawing.Size(68, 20);
            this.RecievingDesklabel4.TabIndex = 7;
            this.RecievingDesklabel4.Text = "Quantity";
            // 
            // PartName Text box
            // 
            this.PartNameText.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.PartNameText.Location = new System.Drawing.Point(200, 265);
            this.PartNameText.Name = "PartNameText";
            this.PartNameText.Size = new System.Drawing.Size(129, 26);
            this.PartNameText.TabIndex = 4;
            // 
            // Quantity
            // 
            this.QuantityText.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.QuantityText.Location = new System.Drawing.Point(500, 265);
            this.QuantityText.Name = "QuantityText";
            this.QuantityText.Size = new System.Drawing.Size(129, 26);
            this.QuantityText.TabIndex = 4;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 318);
            this.RIFW.Controls.Add(this.Quantity);
            this.RIFW.Controls.Add(this.PartName);
            this.RIFW.Controls.Add(this.QuantityText);
            this.RIFW.Controls.Add(this.PartNameText);
            this.RIFW.Controls.Add(this.RecievingDesklabel4);
            this.RIFW.Controls.Add(this.RecievingDesklabel3);
            this.RIFW.Controls.Add(this.RecievingDesklabel2);
            this.RIFW.Controls.Add(this.NumRecieved);
            this.RIFW.Controls.Add(this.Clear);
            this.RIFW.Controls.Add(this.CheckAccept);
            this.RIFW.Controls.Add(this.RecievingDesklabel1);
            this.RIFW.Controls.Add(this.ItemRecievedCode);

        }

        #endregion

        // UI Code
        private System.Windows.Forms.Panel Login;
        private System.Windows.Forms.Label UIlabel3;
        private System.Windows.Forms.Label UIlabel2;
        private System.Windows.Forms.Button LOGIN_UIbutton;
        private System.Windows.Forms.TextBox PW_entry;
        private System.Windows.Forms.TextBox ID_entry;
        private System.Windows.Forms.TextBox PartNameText;
        private System.Windows.Forms.TextBox QuantityText;
        private System.Windows.Forms.Label UIlabel1;
        private System.Windows.Forms.Panel MainPanel;
        private System.Windows.Forms.Button LOGOFF;
        private System.Windows.Forms.Button CSTP_UIbutton;
        private System.Windows.Forms.Button AIAW_UIbutton;
        private System.Windows.Forms.Button AI_UIbutton;
        private System.Windows.Forms.Button RIFW_UIbutton;
        private System.Windows.Forms.Button PPL_UIbutton;
        private System.Windows.Forms.Label UIlabel4;
        private System.Windows.Forms.Button UIbutton8;
        private System.Windows.Forms.Label RecieveItem_Title;
        private System.Windows.Forms.Button UIbutton9;
        private System.Windows.Forms.Label UIlabel5;
        private System.Windows.Forms.Panel Invalid_IDPW;
        private System.Windows.Forms.Label Invalid_flag;
        private System.Windows.Forms.Panel PrintPackingList;
        private System.Windows.Forms.Label UIlabel8;
        private System.Windows.Forms.Panel RIFW;
        private System.Windows.Forms.Panel AddInvoice;
        private System.Windows.Forms.Label UIlabel10;
        private System.Windows.Forms.Panel AIAW;
        private System.Windows.Forms.Label UIlabel11;
        private System.Windows.Forms.Panel CSTP;
        private System.Windows.Forms.Label UIlabel12;
        private System.Windows.Forms.Button UIbutton2;
        private System.Windows.Forms.Button UIbutton1;
        private System.Windows.Forms.Panel CancelPrompt;
        private System.Windows.Forms.Button UIbutton4;
        private System.Windows.Forms.Button UIbutton3;
        private System.Windows.Forms.Label UIlabel7;
        private System.Windows.Forms.Button UIbutton6;
        private System.Windows.Forms.Button UIbutton5;
        private System.Windows.Forms.Button UIbutton15;
        private System.Windows.Forms.Button UIbutton7;
        private System.Windows.Forms.Button UIbutton17;
        private System.Windows.Forms.Button UIbutton16;
        private System.Windows.Forms.Button UIbutton19;
        private System.Windows.Forms.Button UIbutton18;

        // Recieving Desk Code
        private System.Windows.Forms.TextBox ItemRecievedCode;
        private System.Windows.Forms.Label RecievingDesklabel1;
        private System.Windows.Forms.Button CheckAccept;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.TextBox NumRecieved;
        private System.Windows.Forms.Label RecievingDesklabel2;
        private System.Windows.Forms.Label RecievingDesklabel3;
        private System.Windows.Forms.Label RecievingDesklabel4;
        private System.Windows.Forms.Label PartName;
        private System.Windows.Forms.Label Quantity;

        // Add Item Code
        private System.Windows.Forms.TextBox AddItemPartID;
        private System.Windows.Forms.TextBox AddItemQuantity;
        private System.Windows.Forms.TextBox AddItemReason;
        private System.Windows.Forms.Label AddItemPartIDLabel;
        private System.Windows.Forms.Label AddItemQuantityLabel;
        private System.Windows.Forms.Label AddItemReasonLabel;
        private System.Windows.Forms.Button AddItem;
    }
}

